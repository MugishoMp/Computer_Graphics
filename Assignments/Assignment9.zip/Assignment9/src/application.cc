#include "application.h"
#include "grassMesh.h"
#include "fieldMesh.h"
#include "globalVariables.h"
#include "errorChecking.h"
// #include <glm/gtc/matrix_transform.hpp>

Application::Application() {
    // initialize program
    window = std::make_unique<Window>(state.width, state.height, "OpenGL Window");
    // state = 

    // vertex specification
    meshes.push_back(std::make_unique<GrassMesh>(grassMeshVertices, grassMeshIndices));
    meshes.push_back(std::make_unique<FieldMesh>(fieldMeshVertices, fieldMeshIndices));

    // create graphics pipeline

    // Setup input handler
    inputHandler = std::make_unique<InputHandler>();
}

void Application::Run() {

    // TEMPORARY
    Shader grassShader("./shaders/grassVert.glsl", "./shaders/grassFrag.glsl");
    Shader fieldShader("./shaders/fieldVert.glsl", "./shaders/fieldFrag.glsl");
    // TEMPORARY


    while (!this->state.quit) {
        // Handle input
        inputHandler->Update(this->state);

        // // PreRender
        renderer->PreRender(this->state);

        // Render
        for (const auto& mesh : meshes) {
            if (auto grassMesh = dynamic_cast<GrassMesh*>(mesh.get())) {
                // Render grass mesh
                std::cout << "grass" << std::endl;
                renderer->Render(*grassMesh, grassShader, this->state);
            } else if (auto fieldMesh = dynamic_cast<FieldMesh*>(mesh.get())) {
                // Render box mesh
                std::cout << "box" << std::endl;
                renderer->Render(*fieldMesh, fieldShader, this->state);
            }
        }

        // Swap the window buffers
        window->SwapBuffers();
    }
}

void Application::Cleanup() {
    // Cleanup resources
    // The unique_ptr will automatically deallocate memory
}

Application::~Application() {
    Cleanup();
}
